/* Random Relay Controller 4CH - Arduino Uno
   Protocol 115200 baud, newline terminated: PING, STATUS, RESET, A, B, C, D, RANDOM
   Responses: READY, STATE:<A|B|C|D|NONE>, ERR:<reason>
   Default relay modules: active LOW. Change RELAY_ACTIVE_LOW if necessary.
*/
const byte pins[4] = {4, 5, 6, 7};
const bool RELAY_ACTIVE_LOW = true;
const unsigned long BREAK_MS = 150;
int active = -1;
char input[24];
byte length = 0;

void setChannel(byte i, bool on) {
  digitalWrite(pins[i], on == RELAY_ACTIVE_LOW ? LOW : HIGH);
}
void allOff() {
  for (byte i=0; i<4; i++) setChannel(i, false);
  active = -1;
}
void reportState() {
  Serial.print(F("STATE:"));
  if (active < 0) Serial.println(F("NONE"));
  else Serial.println((char)('A' + active));
}
void selectChannel(int channel) {
  allOff();
  delay(BREAK_MS); // break-before-make
  if (channel >= 0 && channel < 4) {
    setChannel((byte)channel, true);
    active = channel;
  }
  reportState();
}
void handle(char* cmd) {
  if (!strcmp(cmd, "PING")) { Serial.println(F("PONG")); reportState(); }
  else if (!strcmp(cmd, "STATUS")) reportState();
  else if (!strcmp(cmd, "RESET")) selectChannel(-1);
  else if (!strcmp(cmd, "RANDOM")) selectChannel(random(0, 4));
  else if (strlen(cmd)==1 && cmd[0]>='A' && cmd[0]<='D') selectChannel(cmd[0]-'A');
  else Serial.println(F("ERR:UNKNOWN_COMMAND"));
}
void setup() {
  // Set output latch to OFF before switching to OUTPUT to minimize activation glitches.
  for (byte i=0; i<4; i++) {
    digitalWrite(pins[i], RELAY_ACTIVE_LOW ? HIGH : LOW);
    pinMode(pins[i], OUTPUT);
  }
  allOff();
  Serial.begin(115200);
  randomSeed(analogRead(A0) ^ micros()); // A0 left floating; pseudo-random, not security grade
  Serial.println(F("READY"));
  reportState();
}
void loop() {
  while (Serial.available()) {
    char c = Serial.read();
    if (c == '\r') continue;
    if (c == '\n') {
      input[length] = '\0';
      if (length) handle(input);
      length = 0;
    } else if (length < sizeof(input)-1) {
      if (c >= 'a' && c <= 'z') c -= 32;
      input[length++] = c;
    } else {
      length = 0;
      Serial.println(F("ERR:LINE_TOO_LONG"));
    }
  }
}
