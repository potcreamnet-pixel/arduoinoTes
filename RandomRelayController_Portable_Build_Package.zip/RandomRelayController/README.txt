RANDOM RELAY CONTROLLER 4 CHANNEL v1.0
====================================
ISI PAKET
firmware/RandomRelayController.ino - kode Arduino Uno
windows_app/app.py - aplikasi Windows berbasis PySide6
windows_app/requirements.txt - dependensi build
windows_app/run_app.bat - menjalankan aplikasi dari source (perlu Python)
windows_app/build_exe.bat - membuat EXE di Windows (perlu Python saat build)
.github/workflows/build-windows.yml - membangun EXE melalui GitHub Actions
BUILD_PORTABLE_EXE_TANPA_PYTHON_LOKAL.txt - panduan build tanpa Python lokal

PERSIAPAN HARDWARE
Arduino Uno D4 -> IN1, D5 -> IN2, D6 -> IN3, D7 -> IN4
GND Arduino -> GND relay; VCC/JD-VCC sesuai datasheet modul.
Modul relay 4 channel dapat membutuhkan catu daya 5V eksternal dengan arus cukup.
Jangan mengasumsikan USB Uno mampu memasok seluruh relay. Gunakan catu daya sesuai
spesifikasi modul dan ground bersama bila diperlukan; hindari backfeed catu daya.
Firmware default untuk relay active LOW. Untuk active HIGH, ubah
RELAY_ACTIVE_LOW = false.
COM/NC/NO adalah kontak terpisah dari pin kontrol IN.

FIRMWARE
1. Instal Arduino IDE dan driver USB Arduino Uno jika dibutuhkan.
2. Buka firmware/RandomRelayController.ino, pilih board Arduino Uno dan COM port.
3. Upload satu kali ke board.

MEMBUAT APLIKASI PORTABLE EXE TANPA PYTHON DI PC LOKAL
Ikuti BUILD_PORTABLE_EXE_TANPA_PYTHON_LOKAL.txt.
GitHub Actions akan membangun satu file RandomRelayController.exe di server
Windows. PC tujuan tidak perlu Python.

ALTERNATIF BUILD LOKAL
Di Windows dengan Python 3.11/3.12 64-bit, jalankan windows_app/build_exe.bat.
Hasilnya windows_app/dist/RandomRelayController.exe.

PENGGUNAAN
1. Hubungkan Arduino ke PC melalui USB.
2. Jalankan RandomRelayController.exe.
3. Pilih COM port Arduino, klik Connect, tunggu sekitar 2 detik.
4. Klik A/B/C/D, ACAK, atau RESET NC.

PERILAKU
A/B/C/D: semua relay OFF, jeda 150 ms, kemudian relay terpilih ON.
RANDOM: pilihan pseudorandom 0..3 (peluang nominal 25% masing-masing).
RESET: semua OFF (COM ke NC, bila wiring sesuai dan modul berfungsi).
Relay tetap ON sampai perintah berikutnya atau Arduino direset/dimatikan.
Status UI berdasarkan konfirmasi firmware, bukan sensor fisik posisi kontak.
Jika USB terputus, status fisik relay tidak dapat dipastikan.

PENTING UNTUK KESELAMATAN
- Uji awal tanpa beban listrik, gunakan LED/tester tegangan rendah.
- Jangan menyambungkan 220 VAC tanpa teknisi kompeten dan pelindung sesuai standar.
- Modul relay mekanis bisa mengalami glitch saat boot/reset tergantung modul.
- NC bukan posisi aman untuk semua jenis beban; NC tersambung ke COM ketika coil
  tidak aktif. Rancang interlock/fail-safe hardware bila aplikasinya kritis.
- Tidak dirancang untuk keselamatan jiwa atau kendali mesin berbahaya.
