@echo off
cd /d "%~dp0"
python -m pip install -r requirements.txt
if errorlevel 1 goto error
python -m PyInstaller --noconfirm --clean --onefile --windowed --name RandomRelayController app.py
if errorlevel 1 goto error
echo.
echo EXE tersedia di folder dist\RandomRelayController.exe
pause
exit /b 0
:error
echo Build gagal. Periksa Python, pip, dan pesan error di atas.
pause
exit /b 1
