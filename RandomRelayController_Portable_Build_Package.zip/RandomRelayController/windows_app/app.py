"""Random Relay Controller 4CH - Windows desktop UI (PySide6 + pyserial)."""
import sys
import time
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QObject, QThread, QTimer, Signal, Slot, Qt
from PySide6.QtWidgets import (QApplication, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QComboBox, QTextEdit, QMessageBox, QGroupBox, QGridLayout)
from serial import Serial, SerialException
from serial.tools import list_ports

class SerialWorker(QObject):
    line = Signal(str)
    failed = Signal(str)
    finished = Signal()

    def __init__(self, port):
        super().__init__()
        self.port = port
        self.serial = None
        self.running = True
        self.commands = []
        from threading import Lock
        self.lock = Lock()

    @Slot()
    def run(self):
        try:
            self.serial = Serial(self.port, 115200, timeout=0.1, write_timeout=1)
            # Arduino Uno resets on serial port open.
            time.sleep(2.2)
            self.serial.reset_input_buffer()
            self.serial.write(b'STATUS\n')
            self.line.emit('LINK:CONNECTED')
            buffer = bytearray()
            while self.running:
                with self.lock:
                    pending = self.commands[:]
                    self.commands.clear()
                for cmd in pending:
                    self.serial.write((cmd + '\n').encode('ascii'))
                chunk = self.serial.read(64)
                for b in chunk:
                    if b == 10:
                        if buffer:
                            self.line.emit(buffer.decode('ascii', errors='replace').strip())
                        buffer.clear()
                    elif b != 13:
                        if len(buffer) < 128:
                            buffer.append(b)
                        else:
                            buffer.clear()
        except (SerialException, OSError) as exc:
            self.failed.emit(str(exc))
        finally:
            if self.serial:
                try: self.serial.close()
                except Exception: pass
            self.finished.emit()

    def send(self, command):
        with self.lock:
            self.commands.append(command)

    def stop(self):
        self.running = False

class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('Random Relay Controller 4CH | v1.0')
        self.resize(680, 560)
        self.worker = None
        self.thread = None
        self.connected = False
        self.current_state = 'NONE'
        self.setStyleSheet('''
            QWidget { background:#101827; color:#e5eaf2; font-size:14px; }
            QGroupBox { border:1px solid #334155; border-radius:10px; margin-top:12px; padding:15px; font-weight:bold; }
            QGroupBox::title { subcontrol-origin:margin; left:12px; padding:0 5px; }
            QPushButton { background:#2563eb; padding:12px; border-radius:8px; font-weight:bold; }
            QPushButton:hover { background:#1d4ed8; }
            QPushButton:disabled { background:#334155; color:#94a3b8; }
            QComboBox { background:#1e293b; border:1px solid #475569; padding:8px; border-radius:6px; }
            QTextEdit { background:#0b1220; border:1px solid #334155; border-radius:6px; }
        ''')
        layout = QVBoxLayout(self)
        title = QLabel('RANDOM RELAY CONTROLLER')
        title.setStyleSheet('font-size:23px; font-weight:900; color:#7dd3fc;')
        layout.addWidget(title)
        layout.addWidget(QLabel('Arduino Uno  •  USB Serial  •  4 Channel'))
        connection = QHBoxLayout()
        self.ports = QComboBox()
        self.refresh_button = QPushButton('Refresh Port')
        self.connect_button = QPushButton('Connect')
        connection.addWidget(self.ports, 2)
        connection.addWidget(self.refresh_button)
        connection.addWidget(self.connect_button)
        layout.addLayout(connection)
        self.connection_label = QLabel('● Disconnected')
        self.connection_label.setStyleSheet('color:#fca5a5; font-weight:bold;')
        layout.addWidget(self.connection_label)
        box = QGroupBox('STATUS KONTAK RELAY')
        grid = QGridLayout(box)
        self.statuses = {}
        for i, name in enumerate('ABCD'):
            label = QLabel(f'Relay {name}\nNC  •  Standby')
            label.setAlignment(Qt.AlignCenter)
            label.setMinimumHeight(72)
            self.statuses[name] = label
            grid.addWidget(label, i//2, i%2)
        layout.addWidget(box)
        controls = QGroupBox('KONTROL MANUAL')
        control_row = QHBoxLayout(controls)
        self.manual_buttons = []
        for name in 'ABCD':
            btn = QPushButton('RELAY ' + name)
            btn.clicked.connect(lambda checked=False, n=name: self.send(n))
            control_row.addWidget(btn)
            self.manual_buttons.append(btn)
        layout.addWidget(controls)
        action = QHBoxLayout()
        self.random_button = QPushButton('🎲 ACAK')
        self.reset_button = QPushButton('RESET → NC')
        self.reset_button.setStyleSheet('background:#b45309; padding:12px; border-radius:8px; font-weight:bold;')
        action.addWidget(self.random_button, 2)
        action.addWidget(self.reset_button, 1)
        layout.addLayout(action)
        self.last_result = QLabel('Hasil terakhir: —')
        self.last_result.setStyleSheet('font-size:17px; font-weight:bold;')
        layout.addWidget(self.last_result)
        layout.addWidget(QLabel('RIWAYAT / LOG'))
        self.log = QTextEdit()
        self.log.setReadOnly(True)
        layout.addWidget(self.log)
        self.refresh_button.clicked.connect(self.refresh_ports)
        self.connect_button.clicked.connect(self.toggle_connection)
        self.random_button.clicked.connect(lambda: self.send('RANDOM'))
        self.reset_button.clicked.connect(lambda: self.send('RESET'))
        self.refresh_ports()
        self.update_ui()

    def refresh_ports(self):
        previous = self.ports.currentData()
        self.ports.clear()
        for port in list_ports.comports():
            self.ports.addItem(f'{port.device} — {port.description}', port.device)
        if previous:
            index = self.ports.findData(previous)
            if index >= 0: self.ports.setCurrentIndex(index)

    def toggle_connection(self):
        if self.thread is not None:
            self.worker.stop()
            self.connect_button.setEnabled(False)
            return
        port = self.ports.currentData()
        if not port:
            QMessageBox.warning(self, 'Port belum dipilih', 'Hubungkan Arduino lalu klik Refresh Port.')
            return
        self.worker = SerialWorker(port)
        self.thread = QThread()
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.run)
        self.worker.line.connect(self.handle_line)
        self.worker.failed.connect(self.handle_error)
        self.worker.finished.connect(self.thread.quit)
        self.thread.finished.connect(self.cleanup_thread)
        self.thread.start()
        self.connect_button.setText('Connecting…')
        self.connect_button.setEnabled(False)
        self.write_log('Membuka ' + port)

    @Slot(str)
    def handle_line(self, line):
        if line == 'LINK:CONNECTED':
            self.connected = True
            self.connection_label.setText('● Connected')
            self.connection_label.setStyleSheet('color:#86efac; font-weight:bold;')
            self.connect_button.setText('Disconnect')
            self.connect_button.setEnabled(True)
            self.update_ui()
            self.write_log('Arduino terhubung')
        elif line.startswith('STATE:'):
            state = line[6:]
            if state in ('A', 'B', 'C', 'D', 'NONE'):
                self.current_state = state
                self.last_result.setText('Hasil terakhir: ' + ('Semua NC' if state == 'NONE' else 'Relay ' + state))
                self.update_ui()
                self.write_log('Status: ' + state)
        elif line:
            self.write_log('Arduino: ' + line)

    @Slot(str)
    def handle_error(self, message):
        self.write_log('ERROR: ' + message)
        QMessageBox.warning(self, 'Serial Error', message)

    @Slot()
    def cleanup_thread(self):
        self.connected = False
        self.current_state = 'NONE'
        self.worker = None
        self.thread.deleteLater()
        self.thread = None
        self.connection_label.setText('● Disconnected')
        self.connection_label.setStyleSheet('color:#fca5a5; font-weight:bold;')
        self.connect_button.setText('Connect')
        self.connect_button.setEnabled(True)
        self.update_ui()
        self.write_log('Koneksi terputus. Status fisik relay tidak diketahui.')

    def update_ui(self):
        for name, label in self.statuses.items():
            active = self.current_state == name and self.connected
            label.setText(f'Relay {name}\n' + ('NO  •  AKTIF' if active else 'NC  •  Standby' if self.connected else '—  •  Offline'))
            label.setStyleSheet('background:' + ('#14532d' if active else '#1e293b') + '; border-radius:8px; font-weight:bold;')
        for btn in self.manual_buttons + [self.random_button, self.reset_button]:
            btn.setEnabled(self.connected)

    def send(self, command):
        if self.connected and self.worker:
            self.worker.send(command)
            self.write_log('Perintah: ' + command)

    def write_log(self, message):
        self.log.append(f'[{datetime.now():%H:%M:%S}] {message}')

    def closeEvent(self, event):
        if self.worker and self.thread:
            self.worker.stop()
            self.thread.quit()
            if not self.thread.wait(3000):
                event.ignore()
                QMessageBox.warning(self, 'Tunggu', 'Menunggu koneksi serial berhenti. Coba tutup kembali.')
                return
        event.accept()

if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
